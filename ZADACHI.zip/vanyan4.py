from vanyan2 import Discipline


class DisciplineFactory:
    _cache = {}

    @classmethod
    def get(cls, name):
        if name not in cls._cache:
            cls._cache[name] = Discipline(name)
        return cls._cache[name]

# Пример:
math1 = DisciplineFactory.get("Математика")
math2 = DisciplineFactory.get("Математика")
print(math1 is math2)  # True — один и тот же объект
