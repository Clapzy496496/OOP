from openpyxl import Workbook
from vanyan2 import *
# создаём объекты
t = Teacher("Иванов И.И.")
d = Discipline("Математика")
g = Group("ПИ-101")

# журнал и занятия
j = Journal()
j.add(Lesson("2025-09-10", t, d, g, 2))
j.add(Lesson("2025-09-11", t, d, g, 3))

# считаем нагрузку
total_hours = sum(l.hours for l in j.lessons if l.teacher == t)

# создаём отчёт в Excel
wb = Workbook()
ws = wb.active
ws.append(["Преподаватель", "Часы"])
ws.append([t.name, total_hours])
wb.save("report.xlsx")

print("Отчёт сохранён в report.xlsx")
